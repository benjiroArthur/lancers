-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2020 at 10:00 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lancers`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_details`
--

CREATE TABLE `account_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `wallet_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `profile_picture` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noimage.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `friend_id` bigint(20) UNSIGNED NOT NULL,
  `chat` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `profile_picture` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noimage.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `email`, `first_name`, `last_name`, `other_name`, `gender`, `dob`, `profile_picture`, `created_at`, `updated_at`) VALUES
(1, 'bruce.wisoky@example.org', 'Flossie', 'Fritsch', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:22', '2020-05-24 04:00:22'),
(2, 'isobel.wehner@example.net', 'Calista', 'Herzog', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:22', '2020-05-24 04:00:22'),
(3, 'treva74@example.com', 'Providenci', 'Quitzon', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:22', '2020-05-24 04:00:22'),
(4, 'jessica74@example.org', 'Ron', 'Prosacco', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(5, 'mhilpert@example.com', 'Frederic', 'Kling', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(6, 'adrianna.johns@example.com', 'Berta', 'Schuster', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(7, 'price.allie@example.org', 'Akeem', 'Mayert', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(8, 'stamm.fay@example.net', 'Emery', 'Treutel', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(9, 'ublanda@example.org', 'Brent', 'Donnelly', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(10, 'alia.padberg@example.com', 'Jewel', 'Mueller', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(11, 'new@gmail.com', NULL, NULL, NULL, NULL, NULL, 'noimage.jpg', '2020-05-29 08:29:02', '2020-05-29 08:29:02');

-- --------------------------------------------------------

--
-- Table structure for table `country_codes`
--

CREATE TABLE `country_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `failed_jobs`
--

INSERT INTO `failed_jobs` (`id`, `connection`, `queue`, `payload`, `exception`, `failed_at`) VALUES
(1, 'database', 'default', '{\"uuid\":\"c3042a6a-6d27-4d21-a4f4-3642eb3d152f\",\"displayName\":\"App\\\\Notifications\\\\PasswordResetNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"delay\":null,\"timeout\":null,\"timeoutAt\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":13:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:8:\\\"App\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:1:{i:0;s:8:\\\"userable\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\PasswordResetNotification\\\":10:{s:5:\\\"token\\\";s:64:\\\"cbcbcb2cc122ea6fbf765c10fe49faeda4b5c67c00ddcba195945dbc30e232cc\\\";s:2:\\\"id\\\";s:36:\\\"b6b2c818-5eb7-43d5-a556-8b6dbfb7c540\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 'Swift_TransportException: Connection could not be established with host smtp.mailtrap.io :stream_socket_client(): php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php:269\nStack trace:\n#0 [internal function]: Swift_Transport_StreamBuffer->{closure}(2, \'stream_socket_c...\', \'C:\\\\xampp\\\\htdocs...\', 272, Array)\n#1 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(272): stream_socket_client(\'smtp.mailtrap.i...\', 0, \'php_network_get...\', 30, 4, Resource id #1044)\n#2 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(58): Swift_Transport_StreamBuffer->establishSocketConnection()\n#3 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(143): Swift_Transport_StreamBuffer->initialize(Array)\n#4 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(65): Swift_Transport_AbstractSmtpTransport->start()\n#5 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(521): Swift_Mailer->send(Object(Swift_Message), Array)\n#6 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(288): Illuminate\\Mail\\Mailer->sendSwiftMessage(Object(Swift_Message))\n#7 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\Channels\\MailChannel.php(65): Illuminate\\Mail\\Mailer->send(Object(Illuminate\\Support\\HtmlString), Array, Object(Closure))\n#8 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(146): Illuminate\\Notifications\\Channels\\MailChannel->send(Object(App\\User), Object(App\\Notifications\\PasswordResetNotification))\n#9 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(105): Illuminate\\Notifications\\NotificationSender->sendToNotifiable(Object(App\\User), \'725f602d-4b97-4...\', Object(App\\Notifications\\PasswordResetNotification), \'mail\')\n#10 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Traits\\Localizable.php(19): Illuminate\\Notifications\\NotificationSender->Illuminate\\Notifications\\{closure}()\n#11 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(107): Illuminate\\Notifications\\NotificationSender->withLocale(NULL, Object(Closure))\n#12 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\ChannelManager.php(54): Illuminate\\Notifications\\NotificationSender->sendNow(Object(Illuminate\\Database\\Eloquent\\Collection), Object(App\\Notifications\\PasswordResetNotification), Array)\n#13 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\SendQueuedNotifications.php(94): Illuminate\\Notifications\\ChannelManager->sendNow(Object(Illuminate\\Database\\Eloquent\\Collection), Object(App\\Notifications\\PasswordResetNotification), Array)\n#14 [internal function]: Illuminate\\Notifications\\SendQueuedNotifications->handle(Object(Illuminate\\Notifications\\ChannelManager))\n#15 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(33): call_user_func_array(Array, Array)\n#16 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(36): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#17 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(91): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#18 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#19 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(592): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#20 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(94): Illuminate\\Container\\Container->call(Array)\n#21 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#22 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#23 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(98): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#24 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(83): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Notifications\\SendQueuedNotifications), false)\n#25 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#26 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#27 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(85): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#28 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(59): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#29 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#30 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Jobs\\Job->fire()\n#31 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(306): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#32 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(132): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#33 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(112): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#34 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(96): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#35 [internal function]: Illuminate\\Queue\\Console\\WorkCommand->handle()\n#36 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(33): call_user_func_array(Array, Array)\n#37 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(36): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#38 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(91): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#39 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#40 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(592): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#41 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(134): Illuminate\\Container\\Container->call(Array)\n#42 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Command\\Command.php(255): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#43 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#44 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Application.php(912): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#45 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Application.php(264): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#46 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Application.php(140): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#47 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#48 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#49 C:\\xampp\\htdocs\\lancers\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#50 {main}', '2020-05-30 11:52:37'),
(2, 'database', 'default', '{\"uuid\":\"6d01c945-642b-402b-822e-d06f8f6c22ac\",\"displayName\":\"App\\\\Notifications\\\\PasswordResetNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"delay\":null,\"timeout\":null,\"timeoutAt\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":13:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:8:\\\"App\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:1;}s:9:\\\"relations\\\";a:1:{i:0;s:8:\\\"userable\\\";}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:43:\\\"App\\\\Notifications\\\\PasswordResetNotification\\\":10:{s:5:\\\"token\\\";s:64:\\\"99ebba8bcf06d14b3e7b45c7002c40579743c7b5f8e2ea8847133c55748d7ecc\\\";s:2:\\\"id\\\";s:36:\\\"be6d9961-c099-47b7-b669-47166b5c8966\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:4:\\\"mail\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}', 'Swift_TransportException: Connection could not be established with host smtp.mailtrap.io :stream_socket_client(): php_network_getaddresses: getaddrinfo failed: No such host is known.  in C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php:269\nStack trace:\n#0 [internal function]: Swift_Transport_StreamBuffer->{closure}(2, \'stream_socket_c...\', \'C:\\\\xampp\\\\htdocs...\', 272, Array)\n#1 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(272): stream_socket_client(\'smtp.mailtrap.i...\', 0, \'php_network_get...\', 30, 4, Resource id #1106)\n#2 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\StreamBuffer.php(58): Swift_Transport_StreamBuffer->establishSocketConnection()\n#3 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Transport\\AbstractSmtpTransport.php(143): Swift_Transport_StreamBuffer->initialize(Array)\n#4 C:\\xampp\\htdocs\\lancers\\vendor\\swiftmailer\\swiftmailer\\lib\\classes\\Swift\\Mailer.php(65): Swift_Transport_AbstractSmtpTransport->start()\n#5 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(521): Swift_Mailer->send(Object(Swift_Message), Array)\n#6 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Mail\\Mailer.php(288): Illuminate\\Mail\\Mailer->sendSwiftMessage(Object(Swift_Message))\n#7 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\Channels\\MailChannel.php(65): Illuminate\\Mail\\Mailer->send(Object(Illuminate\\Support\\HtmlString), Array, Object(Closure))\n#8 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(146): Illuminate\\Notifications\\Channels\\MailChannel->send(Object(App\\User), Object(App\\Notifications\\PasswordResetNotification))\n#9 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(105): Illuminate\\Notifications\\NotificationSender->sendToNotifiable(Object(App\\User), \'96afb279-eeb9-4...\', Object(App\\Notifications\\PasswordResetNotification), \'mail\')\n#10 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Support\\Traits\\Localizable.php(19): Illuminate\\Notifications\\NotificationSender->Illuminate\\Notifications\\{closure}()\n#11 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\NotificationSender.php(107): Illuminate\\Notifications\\NotificationSender->withLocale(NULL, Object(Closure))\n#12 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\ChannelManager.php(54): Illuminate\\Notifications\\NotificationSender->sendNow(Object(Illuminate\\Database\\Eloquent\\Collection), Object(App\\Notifications\\PasswordResetNotification), Array)\n#13 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Notifications\\SendQueuedNotifications.php(94): Illuminate\\Notifications\\ChannelManager->sendNow(Object(Illuminate\\Database\\Eloquent\\Collection), Object(App\\Notifications\\PasswordResetNotification), Array)\n#14 [internal function]: Illuminate\\Notifications\\SendQueuedNotifications->handle(Object(Illuminate\\Notifications\\ChannelManager))\n#15 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(33): call_user_func_array(Array, Array)\n#16 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(36): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#17 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(91): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#18 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#19 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(592): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#20 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(94): Illuminate\\Container\\Container->call(Array)\n#21 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#22 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#23 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Bus\\Dispatcher.php(98): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#24 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(83): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Notifications\\SendQueuedNotifications), false)\n#25 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(128): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#26 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Pipeline\\Pipeline.php(103): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#27 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(85): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#28 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\CallQueuedHandler.php(59): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Notifications\\SendQueuedNotifications))\n#29 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Jobs\\Job.php(98): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Array)\n#30 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(356): Illuminate\\Queue\\Jobs\\Job->fire()\n#31 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(306): Illuminate\\Queue\\Worker->process(\'database\', Object(Illuminate\\Queue\\Jobs\\DatabaseJob), Object(Illuminate\\Queue\\WorkerOptions))\n#32 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Worker.php(132): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\DatabaseJob), \'database\', Object(Illuminate\\Queue\\WorkerOptions))\n#33 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(112): Illuminate\\Queue\\Worker->daemon(\'database\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#34 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Queue\\Console\\WorkCommand.php(96): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'database\', \'default\')\n#35 [internal function]: Illuminate\\Queue\\Console\\WorkCommand->handle()\n#36 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(33): call_user_func_array(Array, Array)\n#37 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Util.php(36): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#38 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(91): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#39 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#40 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Container\\Container.php(592): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#41 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(134): Illuminate\\Container\\Container->call(Array)\n#42 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Command\\Command.php(255): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#43 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Command.php(121): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#44 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Application.php(912): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#45 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Application.php(264): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#46 C:\\xampp\\htdocs\\lancers\\vendor\\symfony\\console\\Application.php(140): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#47 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Console\\Application.php(93): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#48 C:\\xampp\\htdocs\\lancers\\vendor\\laravel\\framework\\src\\Illuminate\\Foundation\\Console\\Kernel.php(129): Illuminate\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#49 C:\\xampp\\htdocs\\lancers\\artisan(37): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#50 {main}', '2020-05-30 11:53:35');

-- --------------------------------------------------------

--
-- Table structure for table `freelancers`
--

CREATE TABLE `freelancers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `profile_picture` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noimage.jpg',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `freelancers`
--

INSERT INTO `freelancers` (`id`, `email`, `first_name`, `last_name`, `other_name`, `gender`, `dob`, `profile_picture`, `created_at`, `updated_at`) VALUES
(1, 'baby07@example.net', 'Lucious', 'Veum', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(2, 'damaris42@example.org', 'Alphonso', 'Hickle', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(3, 'blaise.rice@example.com', 'Coby', 'Gleichner', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(4, 'meta12@example.com', 'Natalia', 'Lowe', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(5, 'doyle.emanuel@example.org', 'Elias', 'Miller', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(6, 'isabelle.schamberger@example.org', 'Karley', 'Lueilwitz', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(7, 'catherine09@example.org', 'Elenora', 'Mraz', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(8, 'ndouglas@example.org', 'Jordon', 'Hegmann', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(9, 'crystel.johns@example.net', 'Garnet', 'Howe', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(10, 'geo.douglas@example.net', 'Hilbert', 'Howell', NULL, NULL, NULL, 'noimage.jpg', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(11, 'rdmark@gmail.com', NULL, NULL, NULL, NULL, NULL, 'noimage.jpg', '2020-05-25 14:29:21', '2020-05-25 14:29:21'),
(12, 'mann@gmail.com', NULL, NULL, NULL, NULL, NULL, 'noimage.jpg', '2020-05-25 16:51:10', '2020-05-25 16:51:10'),
(13, 'test@gmail.com', NULL, NULL, NULL, NULL, NULL, 'noimage.jpg', '2020-05-27 10:15:33', '2020-05-27 10:15:33'),
(14, 'raybow@gmail.com', NULL, NULL, NULL, NULL, NULL, 'noimage.jpg', '2020-05-30 02:14:29', '2020-05-30 02:14:29');

-- --------------------------------------------------------

--
-- Table structure for table `friends`
--

CREATE TABLE `friends` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `friend_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `f_a_q_s`
--

CREATE TABLE `f_a_q_s` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `question` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_categories`
--

CREATE TABLE `job_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `cover_image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'noimage.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_categories`
--

INSERT INTO `job_categories` (`id`, `name`, `created_at`, `updated_at`, `description`, `cover_image`) VALUES
(3, 'Programming And Tech', '2020-05-22 01:14:09', '2020-05-22 01:14:09', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid architecto', 'noimage.jpg'),
(4, 'Video And Animation', '2020-05-22 01:15:18', '2020-05-22 01:15:18', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid architecto', 'vidanimate.jpg'),
(5, 'Graphic Design', '2020-05-22 01:16:13', '2020-05-22 01:16:13', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid architecto', 'graphicsdes.jpg'),
(6, 'Digital marketting', '2020-05-22 01:16:59', '2020-05-22 01:16:59', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid architecto', 'digitalmark.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `job_histories`
--

CREATE TABLE `job_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `freelancer_id` bigint(20) UNSIGNED NOT NULL,
  `project_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_offereds`
--

CREATE TABLE `job_offereds` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `freelancer_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not started'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_offereds`
--

INSERT INTO `job_offereds` (`id`, `project_id`, `freelancer_id`, `created_at`, `updated_at`, `status`) VALUES
(1, 2, 10, '2020-05-27 13:32:03', '2020-05-27 13:32:03', 'not started'),
(2, 42, 2, '2020-05-27 13:32:03', '2020-05-27 13:32:03', 'not started'),
(3, 6, 13, '2020-05-27 13:32:03', '2020-05-27 13:32:03', 'not started'),
(4, 30, 1, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(5, 38, 10, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(6, 15, 9, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(7, 50, 8, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(8, 26, 6, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(9, 21, 1, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(10, 24, 11, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(11, 35, 8, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(12, 9, 8, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(13, 5, 8, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(14, 43, 10, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(15, 39, 8, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(16, 23, 2, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(17, 37, 11, '2020-05-27 13:32:04', '2020-05-27 13:32:04', 'not started'),
(18, 46, 10, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(19, 12, 3, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(20, 29, 12, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(21, 19, 13, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(22, 34, 6, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(23, 48, 10, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(24, 49, 3, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(25, 40, 13, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'completed'),
(26, 47, 11, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(27, 3, 10, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(28, 41, 10, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(29, 16, 8, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started'),
(30, 4, 9, '2020-05-27 13:32:05', '2020-05-27 13:32:05', 'not started');

-- --------------------------------------------------------

--
-- Table structure for table `job_profiles`
--

CREATE TABLE `job_profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `freelancer_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_types`
--

CREATE TABLE `job_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_category_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_types`
--

INSERT INTO `job_types` (`id`, `name`, `job_category_id`, `created_at`, `updated_at`) VALUES
(4, 'Web Programming', 3, '2020-05-22 01:21:58', '2020-05-22 01:21:58'),
(5, 'Mobile Apps', 3, '2020-05-22 01:23:24', '2020-05-22 01:23:24'),
(6, 'Desktop Applications', 3, '2020-05-22 01:24:14', '2020-05-22 01:24:14'),
(7, 'Frontend Developer', 3, '2020-05-22 01:25:36', '2020-05-22 01:25:36'),
(8, 'Backend Developer', 3, '2020-05-22 01:26:50', '2020-05-22 01:26:50'),
(9, 'Video Editing', 4, '2020-05-22 01:31:10', '2020-05-22 01:31:10'),
(10, 'Logo Animation', 4, '2020-05-22 01:31:48', '2020-05-22 01:31:48'),
(11, 'Product Photography', 4, '2020-05-22 01:33:48', '2020-05-22 01:33:48'),
(12, 'Visual Effects', 4, '2020-05-22 01:34:47', '2020-05-22 01:34:47'),
(13, 'Film Making', 4, '2020-05-22 01:36:15', '2020-05-22 01:36:15'),
(14, 'Illustrations', 5, '2020-05-22 01:39:58', '2020-05-22 01:39:58'),
(15, 'Logo Design', 5, '2020-05-22 01:40:37', '2020-05-22 01:40:37'),
(16, 'UI\\UX Design', 5, '2020-05-22 01:42:31', '2020-05-22 01:42:31'),
(17, 'Brochure And Flyer Design', 5, '2020-05-22 01:43:28', '2020-05-22 01:43:28'),
(18, 'Game Design', 5, '2020-05-22 01:44:19', '2020-05-22 01:44:19'),
(19, 'Social Media Marketing', 6, '2020-05-22 01:47:45', '2020-05-22 01:47:45'),
(20, 'E-Commerce Marketting', 6, '2020-05-22 01:48:38', '2020-05-22 01:48:38'),
(21, 'Content Marketting', 6, '2020-05-22 01:50:39', '2020-05-22 01:50:39'),
(22, 'Influencer Marketting', 6, '2020-05-22 01:51:35', '2020-05-22 01:51:35'),
(23, 'Search Engine Optimazation(SEO)', 6, '2020-05-22 01:52:46', '2020-05-22 01:52:46');

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `freelancer_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(3, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(4, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(5, '2016_06_01_000004_create_oauth_clients_table', 1),
(6, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(7, '2019_08_19_000000_create_failed_jobs_table', 1),
(8, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(9, '2020_03_04_094427_create_admins_table', 1),
(10, '2020_03_04_095049_create_clients_table', 1),
(11, '2020_03_04_095749_create_freelancers_table', 1),
(12, '2020_03_04_095850_create_roles_table', 1),
(13, '2020_03_04_095928_create_addresses_table', 1),
(14, '2020_03_04_100018_create_job_categories_table', 1),
(16, '2020_03_04_100241_create_account_details_table', 1),
(17, '2020_03_04_100320_create_projects_table', 1),
(18, '2020_03_04_100601_create_job_offereds_table', 1),
(19, '2020_03_04_100717_create_projct_applications_table', 1),
(20, '2020_03_04_101015_create_job_profiles_table', 1),
(21, '2020_03_04_101558_create_job_histories_table', 1),
(22, '2020_03_04_102056_create_friends_table', 1),
(23, '2020_03_04_102203_create_chats_table', 1),
(24, '2020_03_04_181822_create_country_codes_table', 1),
(25, '2020_03_05_112936_create_f_a_q_s_table', 1),
(26, '2020_03_05_135158_create_payments_table', 1),
(27, '2014_10_12_100000_create_password_resets_table', 2),
(29, '2020_05_20_234657_update_active_in_users_table', 4),
(30, '2020_05_21_233017_change_category_id_in_jobs_table', 5),
(31, '2020_05_22_235409_add_description_to_job_categories_table', 6),
(32, '2020_05_23_000511_add_cover_image_to_job_categories_table', 7),
(33, '2020_05_23_224445_job_category', 8),
(34, '2020_05_24_120223_add_project_title_to_projects_table', 8),
(35, '2020_05_19_172443_add_status_to_job_offereds_table', 9),
(36, '2020_05_27_150150_update_profile_picture_in_clients_table', 10),
(37, '2020_05_27_150243_update_profile_picture_in_admins_table', 10),
(38, '2020_05_27_150303_update_profile_picture_in_freelancers_table', 10),
(39, '2020_05_28_224209_create_portfolios_table', 11),
(40, '2020_05_28_224728_create_links_table', 11),
(41, '2020_05_29_011259_add_portfolio_updated_to_freelancers_table', 11),
(42, '2020_05_30_111435_change_job_id_to_job_type_id_in__projects_table', 11),
(43, '2020_05_30_112723_change_jobs_to_job_types', 11),
(44, '2020_03_04_100046_create_job_types_table', 12),
(45, '2020_05_30_113919_create_jobs_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('64fb05808b340ad05f930640795e07455ee6542bef3cdcc15b475030efc7bb1293927eaa4061f342', 1, 1, 'authToken', '[]', 0, '2020-05-18 20:43:52', '2020-05-18 20:43:52', '2021-05-18 20:43:52'),
('6b7d9b48758107f0d3fa950d4c0890e79c0a45fec509e7c7a531121c4eb6ec98acfb45451f1b154e', 1, 1, 'authToken', '[]', 0, '2020-05-18 20:49:29', '2020-05-18 20:49:29', '2021-05-18 20:49:29'),
('7c423cadcf433ef097f559d6793422c66c88f69f9c8d3976b5753fda8351ca3d1d0977f76b406e1b', 1, 1, 'authToken', '[]', 0, '2020-05-18 17:08:16', '2020-05-18 17:08:16', '2021-05-18 17:08:16'),
('c792836b9e5c2cfee0df8552dbb5240fa5920410865a06f29edbc627182f326618d66ee6e9a3eaf6', 3, 1, 'authToken', '[]', 0, '2020-05-18 21:55:40', '2020-05-18 21:55:40', '2021-05-18 21:55:40'),
('d4b299e4b8dc09a8375cf2a865790b85146270c3259fce4a17aa31adcfd03f4d265e2a6d32d91eca', 2, 1, 'authToken', '[]', 0, '2020-05-18 21:36:29', '2020-05-18 21:36:29', '2021-05-18 21:36:29');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Lancers Personal Access Client', 'mHKi748VvIhYyZ6hnXR5B6BrzkJUbAB2Sr7oasx1', 'http://localhost', 1, 0, 0, '2020-05-18 17:05:32', '2020-05-18 17:05:32'),
(2, NULL, 'Lancers Password Grant Client', 'BMMCj324ScbbH7fTF7NwN84N5wmpjuVONKRWfxSQ', 'http://localhost', 0, 1, 0, '2020-05-18 17:05:33', '2020-05-18 17:05:33');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-05-18 17:05:32', '2020-05-18 17:05:32');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('treva74@example.com', '$2y$10$ez83xNHCeqHh3D.U5h0f7usrN6cfBGKGAxPPHygXDxUu/c1eH6jHe', '2020-05-25 15:54:51'),
('bruce.wisoky@example.org', '$2y$10$dyy.uz0FDJT0EXHSd.KRC.gZh1bMoW0Y7s07p4OtpilE0D.HtLDAa', '2020-05-30 11:56:09');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sender_id` bigint(20) UNSIGNED NOT NULL,
  `receiver_id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `portfolios`
--

CREATE TABLE `portfolios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `freelancer_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projct_applications`
--

CREATE TABLE `projct_applications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `freelancer_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projct_applications`
--

INSERT INTO `projct_applications` (`id`, `project_id`, `freelancer_id`, `created_at`, `updated_at`) VALUES
(1, 46, 3, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(2, 11, 10, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(3, 1, 2, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(4, 14, 11, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(5, 23, 7, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(6, 40, 13, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(7, 46, 11, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(8, 34, 6, '2020-05-27 13:31:41', '2020-05-27 13:31:41'),
(9, 45, 3, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(10, 48, 5, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(11, 15, 6, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(12, 17, 4, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(13, 10, 11, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(14, 1, 11, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(15, 46, 9, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(16, 46, 2, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(17, 7, 8, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(18, 29, 1, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(19, 27, 6, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(20, 34, 13, '2020-05-27 13:31:42', '2020-05-27 13:31:42'),
(21, 4, 8, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(22, 30, 8, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(23, 49, 10, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(24, 48, 4, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(25, 33, 13, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(26, 24, 12, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(27, 48, 5, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(28, 40, 2, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(29, 6, 4, '2020-05-27 13:31:43', '2020-05-27 13:31:43'),
(30, 41, 10, '2020-05-27 13:31:43', '2020-05-27 13:31:43');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_type_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `project_cost` double NOT NULL,
  `duration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `approved` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `project_title` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `job_type_id`, `client_id`, `description`, `project_cost`, `duration`, `approved`, `created_at`, `updated_at`, `project_title`) VALUES
(1, 18, 2, 'Et officiis voluptatibus qui omnis.', 651, '47', 0, '2020-05-24 12:53:22', '2020-05-24 12:53:22', 'Asperiores rerum.'),
(2, 17, 1, 'Aut quia id est laborum reiciendis sint facere.', 767, '18', 0, '2020-05-24 12:53:22', '2020-05-24 12:53:22', 'Nemo et sed dolores rerum.'),
(3, 22, 1, 'Molestiae sapiente delectus totam aut vero veniam vitae.', 537, '22', 0, '2020-05-24 12:53:22', '2020-05-24 12:53:22', 'Repellendus magnam suscipit.'),
(4, 6, 10, 'Repellat enim autem voluptate sequi.', 169, '43', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Explicabo officiis est.'),
(5, 5, 2, 'Quaerat et eius est ullam.', 310, '36', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Voluptatem delectus sed sit.'),
(6, 10, 10, 'Est ut quo libero cupiditate.', 994, '21', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Eaque quisquam tempora.'),
(7, 21, 5, 'Repellat sunt numquam officiis.', 504, '38', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Autem eos culpa fugit.'),
(8, 5, 5, 'Corrupti quas nihil dignissimos vitae error.', 914, '29', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Expedita iste quia.'),
(9, 19, 3, 'Autem tempore est voluptate quasi laudantium cum.', 543, '45', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Itaque sint est nesciunt.'),
(10, 19, 9, 'Repellendus hic ut qui debitis et officiis.', 291, '43', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Ducimus qui excepturi optio.'),
(11, 17, 4, 'Ut velit ipsa molestiae nam eaque porro.', 222, '37', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Eum voluptatem natus in.'),
(12, 5, 4, 'Commodi quia aut libero illo qui nisi.', 352, '14', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Error dolores quia.'),
(13, 13, 10, 'Doloremque sed quis deserunt asperiores ab.', 272, '18', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Provident culpa odio nulla.'),
(14, 19, 3, 'Est ab porro est illo quod officiis quasi in.', 359, '13', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Et molestias id.'),
(15, 17, 9, 'Ut ex optio non illo sunt.', 980, '16', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Occaecati temporibus neque sit.'),
(16, 18, 3, 'Distinctio autem praesentium ut pariatur dolores cum distinctio.', 465, '37', 0, '2020-05-24 12:53:23', '2020-05-24 12:53:23', 'Ratione dolorem et.'),
(17, 7, 6, 'Ut magnam totam at veniam aut exercitationem harum error.', 206, '24', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Dignissimos natus quia officia.'),
(18, 7, 9, 'Quo voluptas veniam id sed.', 358, '41', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Accusamus cumque unde.'),
(19, 22, 7, 'Laborum quod illo vitae voluptas.', 111, '15', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Sapiente commodi.'),
(20, 10, 5, 'Ut nihil autem ratione necessitatibus sapiente adipisci voluptates a.', 376, '31', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Nihil optio nesciunt ratione.'),
(21, 14, 3, 'Dolores soluta cupiditate est quia sint debitis iure.', 706, '43', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Et eveniet consequuntur.'),
(22, 10, 10, 'Magni mollitia quibusdam atque.', 342, '21', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Quis velit dolorem exercitationem vel.'),
(23, 9, 10, 'Aut dolorum aut et deleniti quibusdam velit quo.', 294, '32', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Et ex aspernatur magni beatae.'),
(24, 13, 3, 'Velit vel modi ut dolor et et.', 509, '33', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Possimus inventore architecto facilis.'),
(25, 23, 3, 'Quia eos aut ea necessitatibus corrupti.', 172, '42', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Incidunt quam laboriosam.'),
(26, 9, 7, 'Natus quam ex error non veniam.', 672, '40', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Velit accusantium est velit.'),
(27, 20, 1, 'Dolorem corrupti molestias quo veritatis totam.', 902, '29', 0, '2020-05-24 12:53:24', '2020-05-24 12:53:24', 'Omnis cum rerum nihil.'),
(28, 6, 2, 'Rem nemo omnis maiores consequatur aliquid delectus et.', 443, '20', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Qui corporis culpa non.'),
(29, 16, 1, 'Et ex quibusdam sequi.', 365, '30', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Saepe ea nostrum harum.'),
(30, 23, 3, 'Quae adipisci quis culpa inventore velit cupiditate.', 748, '31', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Qui et aut aut.'),
(31, 7, 3, 'Eos velit est iusto laudantium.', 412, '42', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Quibusdam qui ducimus.'),
(32, 17, 9, 'Ab consectetur provident architecto odit fugiat dolorum dicta.', 679, '18', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Tenetur dolores soluta eveniet quibusdam.'),
(33, 5, 1, 'Enim quos enim ipsum necessitatibus rem et repellendus.', 475, '34', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Est modi adipisci sit.'),
(34, 18, 4, 'Laborum hic expedita ipsa dolorem distinctio dignissimos et.', 374, '35', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Vel voluptas eum.'),
(35, 20, 6, 'Rerum sunt occaecati iure ratione accusamus qui voluptates.', 683, '49', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Placeat eum.'),
(36, 10, 2, 'Soluta dicta et natus ut iste commodi.', 108, '15', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Voluptatibus id beatae.'),
(37, 13, 1, 'Nobis qui velit corrupti dolore cumque id.', 239, '46', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Voluptatem quasi animi.'),
(38, 22, 3, 'Sit vitae magni accusamus sint.', 106, '48', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Quae explicabo suscipit.'),
(39, 9, 4, 'Quidem consectetur ipsa labore facilis nostrum eius.', 982, '28', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Sed est dolor.'),
(40, 8, 5, 'Magni natus sunt vitae ipsum mollitia voluptatum qui ut.', 840, '40', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Incidunt sint voluptatum aut.'),
(41, 19, 1, 'Aut expedita est nemo ex.', 477, '45', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Aut iste quia error possimus.'),
(42, 11, 4, 'Quo qui saepe laboriosam tenetur esse iusto quod.', 810, '24', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Dolor incidunt veniam.'),
(43, 19, 9, 'Quia tempore est amet.', 650, '44', 0, '2020-05-24 12:53:25', '2020-05-24 12:53:25', 'Autem ut est.'),
(44, 17, 4, 'Omnis eum expedita fugiat nam.', 744, '11', 0, '2020-05-24 12:53:26', '2020-05-24 12:53:26', 'Voluptas dicta possimus.'),
(45, 22, 7, 'Aliquid id iste cumque libero error molestiae.', 347, '11', 0, '2020-05-24 12:53:26', '2020-05-24 12:53:26', 'Quam itaque vel.'),
(46, 9, 3, 'Omnis minima ut minima repellendus libero possimus amet delectus.', 347, '47', 0, '2020-05-24 12:53:26', '2020-05-24 12:53:26', 'Autem praesentium veritatis.'),
(47, 17, 8, 'Autem aperiam soluta nam et quia.', 131, '41', 0, '2020-05-24 12:53:26', '2020-05-24 12:53:26', 'Quasi repellendus tempore.'),
(48, 12, 2, 'Eveniet odit enim odit sunt officia.', 489, '14', 0, '2020-05-24 12:53:26', '2020-05-24 12:53:26', 'Sit optio est.'),
(49, 15, 7, 'Corporis libero quisquam rem nobis.', 850, '23', 0, '2020-05-24 12:53:26', '2020-05-24 12:53:26', 'Quas et nostrum ipsam.'),
(50, 15, 1, 'Magni ea perferendis ab placeat quia.', 664, '16', 0, '2020-05-24 12:53:26', '2020-05-24 12:53:26', 'Debitis maxime quia est.');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'admin', '2020-05-18 16:35:09', '2020-05-18 16:35:09'),
(2, 'client', '2020-05-18 16:35:44', '2020-05-18 16:35:44'),
(3, 'freelancer', '2020-05-18 16:36:25', '2020-05-18 16:36:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `userable_id` bigint(20) UNSIGNED NOT NULL,
  `userable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_updated` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `email_verified_at`, `password`, `role_id`, `userable_id`, `userable_type`, `profile_updated`, `active`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'bruce.wisoky@example.org', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 1, 'App\\Client', 0, 1, 'McZflHBxIPmnmqvXvWLC5Juw6HOWnrnKluNIkOk6UHsdijkKlxyUOITbpGmU', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(2, 'isobel.wehner@example.net', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 2, 'App\\Client', 0, 1, 'ih8gRhvxKx', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(3, 'treva74@example.com', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 3, 'App\\Client', 0, 1, 'S1CEnsGig5', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(4, 'jessica74@example.org', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 4, 'App\\Client', 0, 1, 'pLNKybi1Ia', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(5, 'mhilpert@example.com', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 5, 'App\\Client', 0, 1, 'UcseqK1GBv', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(6, 'adrianna.johns@example.com', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 6, 'App\\Client', 0, 1, 'BQ57I5VnZi', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(7, 'price.allie@example.org', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 7, 'App\\Client', 0, 1, 'y8YkEerHRP', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(8, 'stamm.fay@example.net', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 8, 'App\\Client', 0, 1, 'R2ulEtspgt', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(9, 'ublanda@example.org', '2020-05-24 04:00:23', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 9, 'App\\Client', 0, 1, 'ulEgexmysg', '2020-05-24 04:00:23', '2020-05-24 04:00:23'),
(10, 'alia.padberg@example.com', '2020-05-24 04:00:24', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 2, 10, 'App\\Client', 0, 1, 'DHUZthP25Z', '2020-05-24 04:00:24', '2020-05-24 04:00:24'),
(11, 'baby07@example.net', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 1, 'App\\Freelancer', 0, 1, 'vi0dqM1FTxtZeQhbGHkWsZcNo4aOCqOmYR3Ra4Q0SRC4dzEdd6KuuFswCmC7', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(12, 'damaris42@example.org', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 2, 'App\\Freelancer', 0, 1, 'odeTLS7iSMpaYZgqOCQcxM4OAP64GwCGL5jpzyCvjB2oUWtC3HNjLRTb7BH9', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(13, 'blaise.rice@example.com', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 3, 'App\\Freelancer', 0, 1, 'XMd4uR1GKB', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(14, 'meta12@example.com', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 4, 'App\\Freelancer', 0, 1, 'KMVOoM5K2k', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(15, 'doyle.emanuel@example.org', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 5, 'App\\Freelancer', 0, 1, 'uVMRXPYOWC', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(16, 'isabelle.schamberger@example.org', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 6, 'App\\Freelancer', 0, 1, 'TDOdpzG2mP', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(17, 'catherine09@example.org', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 7, 'App\\Freelancer', 0, 1, 'YUHgPC14H0', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(18, 'ndouglas@example.org', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 8, 'App\\Freelancer', 0, 1, 'XoCoyiupsF', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(19, 'crystel.johns@example.net', '2020-05-24 04:00:25', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 9, 'App\\Freelancer', 0, 1, 'GdSJdxpRYj', '2020-05-24 04:00:25', '2020-05-24 04:00:25'),
(20, 'geo.douglas@example.net', '2020-05-24 04:00:26', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 3, 10, 'App\\Freelancer', 0, 1, 'r3kfCCwKpk', '2020-05-24 04:00:26', '2020-05-24 04:00:26'),
(21, 'rdmark@gmail.com', NULL, '$2y$10$uqihgZgQCgd4CBw09zydTeL1xq9Owvc57sFmR9JoiSaAO0ZUo9JLu', 3, 11, 'App\\Freelancer', 0, 1, NULL, '2020-05-25 14:29:21', '2020-05-25 14:29:21'),
(22, 'mann@gmail.com', '2020-05-25 16:51:30', '$2y$10$6Z30sx86G3w6shLsXI/ceeb866E0Xx3DmEOjjgu4iIw1EfXAvLpta', 3, 12, 'App\\Freelancer', 0, 1, NULL, '2020-05-25 16:51:10', '2020-05-25 16:51:30'),
(23, 'test@gmail.com', '2020-05-27 10:16:02', '$2y$10$0074swiTUBuHmyvzPau3j.tu/dPvZfCQVQWJGdgJHrFUdNfQB9M6a', 3, 13, 'App\\Freelancer', 0, 1, NULL, '2020-05-27 10:15:33', '2020-05-27 10:16:02'),
(24, 'new@gmail.com', '2020-05-29 08:29:48', '$2y$10$u3rfWQsPTa.kCbPawqI2mOweQGuzET6uBPIlq/b.gtAWHAnqyyyVm', 2, 11, 'App\\Client', 0, 1, NULL, '2020-05-29 08:29:03', '2020-05-29 08:29:48'),
(25, 'raybow@gmail.com', '2020-05-30 02:27:49', '$2y$10$HYjNO4Gh4eZZdTeqlG2RMOJiRtQu3dLNvw0MlaVpbPtDMz4dJoGBK', 3, 14, 'App\\Freelancer', 0, 1, NULL, '2020-05-30 02:14:30', '2020-05-30 02:27:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_details`
--
ALTER TABLE `account_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_email_unique` (`email`);

--
-- Indexes for table `country_codes`
--
ALTER TABLE `country_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `freelancers`
--
ALTER TABLE `freelancers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `freelancers_email_unique` (`email`);

--
-- Indexes for table `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `f_a_q_s`
--
ALTER TABLE `f_a_q_s`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_categories`
--
ALTER TABLE `job_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_histories`
--
ALTER TABLE `job_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_offereds`
--
ALTER TABLE `job_offereds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_profiles`
--
ALTER TABLE `job_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_types`
--
ALTER TABLE `job_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `portfolios`
--
ALTER TABLE `portfolios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projct_applications`
--
ALTER TABLE `projct_applications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_details`
--
ALTER TABLE `account_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `country_codes`
--
ALTER TABLE `country_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `freelancers`
--
ALTER TABLE `freelancers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `friends`
--
ALTER TABLE `friends`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `f_a_q_s`
--
ALTER TABLE `f_a_q_s`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_categories`
--
ALTER TABLE `job_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `job_histories`
--
ALTER TABLE `job_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_offereds`
--
ALTER TABLE `job_offereds`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `job_profiles`
--
ALTER TABLE `job_profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_types`
--
ALTER TABLE `job_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `portfolios`
--
ALTER TABLE `portfolios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projct_applications`
--
ALTER TABLE `projct_applications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
